from django.apps import AppConfig


class MessLoginFormConfig(AppConfig):
    name = 'mess_login_form'
